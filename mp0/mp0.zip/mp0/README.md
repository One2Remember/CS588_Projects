################################################################
# Starter Code Only. 
# Do not modify.
# Last update: 09/27/2022
# Author: Rahul Vasanth rvasant2@illinois.edu
################################################################

$ cd ~/demo_ws/
$ catkin_make

$ source devel/setup.bash
$ roslaunch basic_launch gem_dbw_joystick.launch

## Press Back and Start to Enable

$ source devel/setup.bash
$ rosrun mp0 mp0.py
